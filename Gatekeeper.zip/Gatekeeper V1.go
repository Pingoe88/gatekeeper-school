package main

import (
	"fmt"
)

func main() {
	fmt.Println("Welkom bij Fonteyn Vakantieparken")
}
